﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using Intelledox.QAWizard;
using System.Xml.Linq;
using System.Xml;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO.Compression;


namespace CompletePolicyAction
{
    public class CompletePolicyAction : Intelledox.Action.ActionProvider{

        const string PATH_STRING = "Path String";

        private Guid formsGuid = new Guid("8AB2ED1D-3177-40CD-98FF-7979A7139573");
        private Guid output_Path_Sting = new Guid("10256EA7-3EFD-470B-A34A-12D3F4CEBBF7");
        private string _actionTypeName = "Complete Policy Action";
       
        // Constructor - Always needed
        public CompletePolicyAction()
        {
            base.RegisterActionType(ActionTypeID(), "Complete Policy Action II", false);
            base.RegisterActionAttribute(ActionTypeID(), formsGuid, "XML Document of Forms to merge", 1000, true);
            base.RegisterActionOutput(ActionTypeID(), output_Path_Sting, PATH_STRING);
        }

        // This is where the GUID for the Action is registered
        public override Guid ActionTypeID()
        {
            return new Guid("D6194FF3-3376-4F74-8266-31C301C15461");
        }

        // This is where all the work is done
        public override ActionResult Run(ActionProperties properties)
        {
            ActionResult actionResult = new ActionResult();
            XElement policyTree = null;

            //Check Input file exists
            if( properties.ActionInputs.Count == 0)
            {
                throw new ArgumentException("No Action parameters have been set." );
            }

            //get the inputs
            foreach (ActionInput actionInput in properties.ActionInputs)
            {
                if (actionInput.ElementTypeId == formsGuid)
                {

                    if (!string.IsNullOrEmpty(actionInput.OutputValue))
                    {

                        /*
                         * Get the xml stream for the xmlFile from the documents
                         * Parse the XML here.
                         */
                        foreach (Intelledox.Model.Document xmlDoc in properties.Documents)
                        {

                            if (xmlDoc.DisplayName.Equals(actionInput.OutputValue))
                            {
                                try
                                {
                                    policyTree = XElement.Load(properties.GetDocumentStream(xmlDoc));
                                }
                                catch(Exception ex)
                                {
                                    properties.AddMessage("unable to load xml for the following reason: " + ex.Message);
                                    actionResult.Result = Intelledox.QAWizard.Design.ActionResultType.Fail;
                                    return actionResult;
                                }
                            }
                        }
                    }
                    else
                    {
                        throw new ArgumentException("XML file value is empty or null. Please check the action parameter, XML of Forms to merge, has been set." );
                    }

                }

            }

            // Grab the child nodes.

            XElement pathElement = policyTree.Element("Path");
            XElement endOnEvenElement = policyTree.Element("EndOnEvenPage");
            XElement mergedDocumentNameElement = policyTree.Element("MergedDocumentName");
            XElement rePrintFlagElement = policyTree.Element("RePrintFlag");
            XElement lockFileElement = policyTree.Element("LockFile");
            XElement formsTree = policyTree.Element("Forms");


            /*
             *  If Reprint, then just read the file, save it to the project and short circuit the rest of this function.
             */

            if (Boolean.Parse(rePrintFlagElement.Value))
            {
                String reprintFileName = pathElement.Value + @"\" + mergedDocumentNameElement.Value + ".pdf";
                byte[] bytes = System.IO.File.ReadAllBytes(reprintFileName);

                foreach (Intelledox.Model.Document doc in properties.Documents) 
                {
                    if (doc.DisplayName.Equals(mergedDocumentNameElement.Value))
                    {
                        properties.UpdateDocumentBinary(doc, bytes);
                    }
                }
                actionResult.Result = Intelledox.QAWizard.Design.ActionResultType.Success;
                return actionResult;
            }

            /*
             * Create the Master Document
             */

            Aspose.Pdf.Document masterPDF = new Aspose.Pdf.Document();
            Aspose.Words.Document blankDocument = new Aspose.Words.Document();

            /*
             * Loop through the Forms grabbing the Form Element.
             * Keep a list of the page counts for each document, this will be used for the bookmarks.
             */

            List<int> pageCounts = new List<int>();

            foreach (var formElement in formsTree.Elements("Form"))
            {
                XElement filenameElement = formElement.Element("FileName");
                XElement removeWatermarkElement = formElement.Element("RemoveWatermark");
           
                //String docName = pathElement.Value + @"\" + filenameElement.Value;
                String docName = filenameElement.Value;

                if (docName.EndsWith(".docx", StringComparison.OrdinalIgnoreCase))
                {
                    XElement binaryDocumentElement = formElement.Element("BinaryDocument");

                    Aspose.Words.Document document = null;


                    if (binaryDocumentElement.IsEmpty)
                    {
                        /*
                         * If the Binary element is empty then get the Word Document from the file path.
                         */
                        try
                        {
                            document = new Aspose.Words.Document(docName);
                            document.Save("c:\\temp\\"+ docName, Aspose.Words.SaveFormat.Docx);
                        }
                        catch (Exception ex)
                        {
                            properties.AddMessage("unable to load form file (" + docName + ") for following reason: " + ex.Message);
                            actionResult.Result = Intelledox.QAWizard.Design.ActionResultType.Fail;
                            return actionResult;
                        }
                    }
                    else
                    {

                        /*
                         * Get the binary stream for the documents from the XML
                         */

                        byte[] bytes = Convert.FromBase64String(binaryDocumentElement.Value);

                        //File.WriteAllBytes(@"c:\temp\harry.zip", bytes);
                    

                        // Data returned is a Zip archive.  Process the Zip as a stream
                        MemoryStream stream = new MemoryStream(bytes);

                        ZipArchive za = new ZipArchive(stream);

                        // Loop through the Zip entries looking for the word doc.
                        foreach (ZipArchiveEntry entry in za.Entries)
                        {
                            // Open Entry as a stream and create an Aspose Document from it.
                            if (entry.FullName.EndsWith(".docx", StringComparison.OrdinalIgnoreCase))
                            {
                                MemoryStream entryBuf = new MemoryStream();
                                entry.Open().CopyTo(entryBuf);

                                // Create a temporary Aspose document, process it, and add it to the Master.
                                document = new Aspose.Words.Document(entryBuf);
                                document.Save("c:\\temp\\"+ entry.FullName, Aspose.Words.SaveFormat.Docx);
                            }
                        }
                    }

                    /*
                     *  Remove watermarks.
                     */
                    try
                    {
                        if (Boolean.Parse(removeWatermarkElement.Value))
                        {
                            Aspose.Words.NodeCollection shapesColl = document.GetChildNodes(Aspose.Words.NodeType.Shape, true);

                            foreach (Aspose.Words.Node node in shapesColl)
                            {
                                Aspose.Words.Drawing.Shape shape = (Aspose.Words.Drawing.Shape)node;
                                if (shape.Name.Contains("WaterMark"))
                                    shape.Remove();
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        properties.AddMessage("unable to remove watermark on (" + docName + ") for following reason: " + ex.Message);
                        actionResult.Result = Intelledox.QAWizard.Design.ActionResultType.Fail;
                        return actionResult;
                    }


                    /*
                     * Add to masterPDF
                     */
                    System.IO.MemoryStream tempPdfMemoryStream = new System.IO.MemoryStream();
                    document.Save(tempPdfMemoryStream, Aspose.Words.SaveFormat.Pdf);
                    Aspose.Pdf.Document tempPdfDocument = new Aspose.Pdf.Document(tempPdfMemoryStream);
                    masterPDF.Pages.Add(tempPdfDocument.Pages);

                    /*
                     *  Add a Blank page if necessary.
                     */
                    int blankCount = 0;

                    if (Boolean.Parse(endOnEvenElement.Value))
                    {
                        if (document.PageCount % 2 == 1)
                        {
                            masterPDF.Pages.Add();
                            blankCount++;
                        }
                    }

                    /*
                     *  add the bookmark pageCounts.
                     */
                    pageCounts.Add(document.PageCount + blankCount);

                }
                else if (docName.EndsWith(".pdf", StringComparison.OrdinalIgnoreCase))
                {
                    try
                    {
                        Aspose.Pdf.Document document = new Aspose.Pdf.Document(docName);

                        /*
                         *  Add document to the Master
                         */
                        masterPDF.Pages.Add(document.Pages);

                        /*
                         *  Add a Blank page if necessary.
                         */
                        int blankCount = 0;

                        if (Boolean.Parse(endOnEvenElement.Value))
                        {
                            if (document.Pages.Count % 2 == 1)
                            {
                                masterPDF.Pages.Add();
                                blankCount++;
                            }
                        }

                        /*
                         *  add the bookmark pageCounts.
                         */
                        pageCounts.Add(document.Pages.Count + blankCount);
                    }
                    catch (Exception ex)
                    {
                        properties.AddMessage("unable to load form file (" + docName + ") for following reason: " + ex.Message);
                        actionResult.Result = Intelledox.QAWizard.Design.ActionResultType.Fail;
                        return actionResult;
                    }

                }

            } //End foreach forms

            /*
             * Add the Bookmarks.
             */
            try
            {
                int cummulativePageCount = 1;
                int i = 0;
                foreach (var formElement in formsTree.Elements("Form"))
                {
                    XElement bookmarkTitleElement = formElement.Element("BookmarkTitle");

                    Aspose.Pdf.OutlineItemCollection pdfOutlineItem = new Aspose.Pdf.OutlineItemCollection(masterPDF.Outlines);
                    pdfOutlineItem.Title = bookmarkTitleElement.Value;
                    pdfOutlineItem.Action = new Aspose.Pdf.InteractiveFeatures.GoToAction(masterPDF.Pages[cummulativePageCount]);
                    masterPDF.Outlines.Add(pdfOutlineItem);

                    cummulativePageCount = cummulativePageCount + pageCounts.ElementAt(i);
                    i++;
                }
            }
            catch (Exception ex)
            {
                properties.AddMessage("unable to add bookmarks to the Masterfile for following reason: " + ex.Message);
                actionResult.Result = Intelledox.QAWizard.Design.ActionResultType.Fail;
                return actionResult;
            }

            /*
             * Write the Document to Intelledox.
             */

            System.IO.MemoryStream updatedPdfMemoryStream = new System.IO.MemoryStream();

            /*
             * Lock the PDF as requested.
             */

            try
            {
                if (Boolean.Parse(lockFileElement.Value))
                {
                    Aspose.Pdf.Facades.DocumentPrivilege documentPrivilege = Aspose.Pdf.Facades.DocumentPrivilege.ForbidAll;
                    documentPrivilege.AllowScreenReaders = true;
                    documentPrivilege.AllowPrint = true;

                    masterPDF.Encrypt("", "owner", documentPrivilege, Aspose.Pdf.CryptoAlgorithm.AESx128, false);
                }
            }
            catch (Exception ex)
            {
                properties.AddMessage("unable to lock the masterfile for following reason: " + ex.Message);
                actionResult.Result = Intelledox.QAWizard.Design.ActionResultType.Fail;
                return actionResult;
            }


            masterPDF.Save(updatedPdfMemoryStream, Aspose.Pdf.SaveFormat.Pdf);


            foreach (Intelledox.Model.Document doc in properties.Documents)
            {
                 if (doc.DisplayName.Equals(mergedDocumentNameElement.Value))
                 {
                    properties.UpdateDocumentBinary(doc, updatedPdfMemoryStream.ToArray());
                 }
             }
            updatedPdfMemoryStream.Close();


            // Results
            List<Intelledox.Model.ActionOutput> outputs = new List<Intelledox.Model.ActionOutput>();
            Intelledox.Model.ActionOutput output = new Intelledox.Model.ActionOutput();
            output.ID = output_Path_Sting;
            output.Name = PATH_STRING;
            output.Value = pathElement.Value;
            outputs.Add(output);

            actionResult.Outputs = outputs;
            actionResult.Result = Intelledox.QAWizard.Design.ActionResultType.Success;

            return actionResult;
        }

        public override WebControl CustomUI(ActionProperties properties)
        {
            throw new NotImplementedException();
        }

        public override bool SupportsRun()
        {
            return true;
        }

        public override bool SupportsUI()
        {
            return false;
        }
    }
}
